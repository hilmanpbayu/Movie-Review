#include "fungsional.h"

int main()
{
    goMenu();
}




































